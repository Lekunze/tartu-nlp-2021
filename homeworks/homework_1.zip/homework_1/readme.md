## Homework 1: NLP Basics and NLP Pipelines 

